/**
 * 
 */
/**
 * 
 */
module Ejercicios_interfaz {
	requires java.desktop;
}