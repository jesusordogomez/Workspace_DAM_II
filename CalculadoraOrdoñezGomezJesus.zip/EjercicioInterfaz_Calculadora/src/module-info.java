/**
 * 
 */
/**
 * 
 */
module EjercicioInterfaz_Calculadora {
	requires java.desktop;
	requires java.scripting;
}