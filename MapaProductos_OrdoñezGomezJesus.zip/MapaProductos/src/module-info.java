/**
 * 
 */
/**
 * 
 */
module MapaProductos {
	requires java.desktop;
}