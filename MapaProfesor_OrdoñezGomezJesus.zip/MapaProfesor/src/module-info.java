/**
 * 
 */
/**
 * 
 */
module MapaProfesor {
	requires java.desktop;
}