/**
 * 
 */
/**
 * @author Usuario
 *
 */
module Troll {
	requires java.desktop;
}